const login = () =>{
    alert("You Are Logged In !!");
}

changePassword = () =>{
    alert("Check Your Mail to Reset Your Password.")
}

